realtime-geolocation-demo
=========================

Realtime geolocation app build on Node.js with HTML5 Geolocation API, Socket.io and Leaflet maps library.
Tutorial and how to start with it you can read at http://tympanus.net/codrops/2012/10/11/real-time-geolocation-service-with-node-js/