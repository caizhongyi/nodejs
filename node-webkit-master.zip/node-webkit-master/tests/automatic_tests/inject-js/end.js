var result = result ||[];
result.push('inject-js-end');