document.getElementById("color").focus();$(document).keydown(function(a){13==a.keyCode&&$("body").css("background-color",$("#color").val())});
//@ sourceMappingURL=script.closure.js.map