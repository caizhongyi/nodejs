#!/bin/bash

# Ignore errors from strip.
strip "$@"

exit 0
