exports.call = function(func) {
  return func();
}

exports.constructor = function() {
  this.test = 'test';
}
