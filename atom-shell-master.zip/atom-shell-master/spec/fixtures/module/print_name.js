exports.print = function(obj) {
  return obj.constructor.name;
}
