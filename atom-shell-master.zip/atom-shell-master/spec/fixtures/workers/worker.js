this.onmessage = function(msg) {
  this.postMessage(msg.data);
}
